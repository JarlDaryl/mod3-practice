/* 
EJERCICIO 14:
Muestra un array que solo incluya la pelicula mejor valorada de cada uno de estos actores:
- Leonardo Dicaprio
- Robert De Niro
- Tom Hanks
*/


function mejoresActores() {
    let mejorValorada = [];
    let actores = ["Leonardo Dicaprio", "Robert De Niro", "Tom Hanks"]

    for (let index = 0; index < actores.length; index++) {
        let bestFilmOf = movies.filter((film) => film.actores.includes(actores(index)));

    }
}